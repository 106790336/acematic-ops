import { Router, Request, Response } from 'express';
import { prisma } from '../config/database';
import { authMiddleware, roleMiddleware } from '../middleware/auth';
import { validateRequest } from '../middleware/validation';
import { CreateUserSchema, UpdateUserSchema } from '../types';

const router = Router();

// 所有路由需要认证
router.use(authMiddleware);

// 获取用户列表
router.get('/', async (req: Request, res: Response) => {
  try {
    const { departmentId, role, search, page = 1, limit = 20 } = req.query;
    
    const where: any = {};
    
    if (departmentId) {
      where.departmentId = departmentId as string;
    }
    
    if (role) {
      where.role = role as string;
    }
    
    if (search) {
      where.OR = [
        { name: { contains: search as string, mode: 'insensitive' } },
        { username: { contains: search as string, mode: 'insensitive' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);
    
    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        skip,
        take: Number(limit),
        select: {
          id: true,
          username: true,
          name: true,
          role: true,
          roleId: true,
          roleInfo: { select: { id: true, name: true, label: true } },
          departmentId: true,
          department: {
            select: { id: true, name: true },
          },
          position: true,
          avatar: true,
          email: true,
          phone: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.user.count({ where }),
    ]);

    res.json({
      success: true,
      data: {
        items: users,
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      success: false,
      error: '获取用户列表失败',
    });
  }
});

// 获取单个用户
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    const user = await prisma.user.findUnique({
      where: { id },
      include: {
        department: {
          select: { id: true, name: true },
        },
      },
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        error: '用户不存在',
      });
    }

    const { password, ...userWithoutPassword } = user;
    
    res.json({
      success: true,
      data: userWithoutPassword,
    });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({
      success: false,
      error: '获取用户信息失败',
    });
  }
});

// 创建用户（需要管理员权限）
router.post('/', roleMiddleware('ceo', 'executive'), validateRequest(CreateUserSchema), async (req: Request, res: Response) => {
  try {
    const { username, password, name, role, departmentId, position, email, phone } = req.body;

    // 检查用户名是否已存在
    const existingUser = await prisma.user.findUnique({
      where: { username },
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: '用户名已存在',
      });
    }

    const bcrypt = require('bcryptjs');
    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: {
        username,
        password: hashedPassword,
        name,
        role,
        departmentId,
        position,
        email,
        phone,
      },
    });

    const { password: _, ...userWithoutPassword } = user;
    
    res.json({
      success: true,
      data: userWithoutPassword,
    });
  } catch (error) {
    console.error('Create user error:', error);
    res.status(500).json({
      success: false,
      error: '创建用户失败',
    });
  }
});

// 更新用户
router.put('/:id', validateRequest(UpdateUserSchema), async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    // 如果更新密码，需要加密
    if (updateData.password) {
      const bcrypt = require('bcryptjs');
      updateData.password = await bcrypt.hash(updateData.password, 10);
    }

    const user = await prisma.user.update({
      where: { id },
      data: updateData,
    });

    const { password, ...userWithoutPassword } = user;
    
    res.json({
      success: true,
      data: userWithoutPassword,
    });
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({
      success: false,
      error: '更新用户失败',
    });
  }
});

// 删除用户（需要CEO权限）
router.delete('/:id', roleMiddleware('ceo'), async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    await prisma.user.delete({
      where: { id },
    });

    res.json({
      success: true,
      message: '用户已删除',
    });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({
      success: false,
      error: '删除用户失败',
    });
  }
});

export default router;
