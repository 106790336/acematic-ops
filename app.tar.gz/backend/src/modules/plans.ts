import { Router, Request, Response } from 'express';
import { prisma } from '../config/database';
import { authMiddleware } from '../middleware/auth';
import { validateRequest } from '../middleware/validation';
import { CreatePlanSchema, UpdatePlanSchema } from '../types';

const router = Router();

router.use(authMiddleware);

// 获取计划列表
router.get('/', async (req: Request, res: Response) => {
  try {
    const { type, status, departmentId, strategyId, search, page = 1, limit = 10 } = req.query;
    
    const where: any = {};
    
    if (type) {
      where.type = type as string;
    }
    
    if (status) {
      where.status = status as string;
    }
    
    if (departmentId) {
      where.departmentId = departmentId as string;
    }
    
    if (strategyId) {
      where.strategyId = strategyId as string;
    }
    
    if (search) {
      where.OR = [
        { title: { contains: search as string, mode: 'insensitive' } },
        { description: { contains: search as string, mode: 'insensitive' } },
      ];
    }

    // 非CEO和高管只能看到自己部门或自己的计划
    if (req.user!.role === 'employee' || req.user!.role === 'manager') {
      where.OR = [
        { ownerId: req.user!.id },
        { departmentId: req.user!.departmentId },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);
    
    const [plans, total] = await Promise.all([
      prisma.plan.findMany({
        where,
        skip,
        take: Number(limit),
        include: {
          department: {
            select: { id: true, name: true },
          },
          owner: {
            select: { id: true, name: true },
          },
          strategy: {
            select: { id: true, title: true },
          },
          _count: {
            select: { tasks: true },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.plan.count({ where }),
    ]);

    res.json({
      success: true,
      data: {
        items: plans.map(p => ({ ...p, taskCount: p._count.tasks })),
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error('Get plans error:', error);
    res.status(500).json({
      success: false,
      error: '获取计划列表失败',
    });
  }
});

// 获取计划详情
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    const plan = await prisma.plan.findUnique({
      where: { id },
      include: {
        department: {
          select: { id: true, name: true },
        },
        owner: {
          select: { id: true, name: true, position: true },
        },
        strategy: {
          select: { id: true, title: true },
        },
        tasks: {
          include: {
            assignee: {
              select: { id: true, name: true },
            },
          },
        },
        assessments: {
          include: {
            assessor: {
              select: { id: true, name: true },
            },
          },
        },
      },
    });

    if (!plan) {
      return res.status(404).json({
        success: false,
        error: '计划不存在',
      });
    }

    res.json({
      success: true,
      data: plan,
    });
  } catch (error) {
    console.error('Get plan error:', error);
    res.status(500).json({
      success: false,
      error: '获取计划信息失败',
    });
  }
});

// 创建计划
router.post('/', async (req: Request, res: Response) => {
  try {
    const { title, description, type, strategyId, departmentId, startDate, endDate, priority } = req.body;
    
    const plan = await prisma.plan.create({
      data: {
        title,
        description,
        type: type || 'department',
        strategyId: strategyId || null,
        departmentId: departmentId || null,
        ownerId: req.user!.id,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        priority: priority || 'medium',
        status: 'pending',
        progress: 0,
      },
      include: {
        department: {
          select: { id: true, name: true },
        },
        owner: {
          select: { id: true, name: true },
        },
      },
    });

    res.json({
      success: true,
      data: plan,
    });
  } catch (error) {
    console.error('Create plan error:', error);
    res.status(500).json({
      success: false,
      error: '创建计划失败',
    });
  }
});

// 更新计划
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { title, description, type, strategyId, departmentId, startDate, endDate, priority, status, progress } = req.body;
    
    const updateData: any = {};
    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (type !== undefined) updateData.type = type;
    if (strategyId !== undefined) updateData.strategyId = strategyId || null;
    if (departmentId !== undefined) updateData.departmentId = departmentId || null;
    if (startDate !== undefined) updateData.startDate = new Date(startDate);
    if (endDate !== undefined) updateData.endDate = new Date(endDate);
    if (priority !== undefined) updateData.priority = priority;
    if (status !== undefined) updateData.status = status;
    if (progress !== undefined) updateData.progress = progress;
    
    const plan = await prisma.plan.update({
      where: { id },
      data: updateData,
      include: {
        department: {
          select: { id: true, name: true },
        },
        owner: {
          select: { id: true, name: true },
        },
      },
    });

    res.json({
      success: true,
      data: plan,
    });
  } catch (error) {
    console.error('Update plan error:', error);
    res.status(500).json({
      success: false,
      error: '更新计划失败',
    });
  }
});

// 删除计划
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    await prisma.plan.delete({
      where: { id },
    });

    res.json({
      success: true,
      message: '计划已删除',
    });
  } catch (error) {
    console.error('Delete plan error:', error);
    res.status(500).json({
      success: false,
      error: '删除计划失败',
    });
  }
});

export default router;
