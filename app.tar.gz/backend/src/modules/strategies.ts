import { Router, Request, Response } from 'express';
import { prisma } from '../config/database';
import { authMiddleware } from '../middleware/auth';
import { validateRequest } from '../middleware/validation';
import { CreateStrategySchema, UpdateStrategySchema } from '../types';

const router = Router();

router.use(authMiddleware);

// 获取战略列表
router.get('/', async (req: Request, res: Response) => {
  try {
    const { year, status, search, page = 1, limit = 10 } = req.query;
    
    const where: any = {};
    
    if (year) {
      where.year = Number(year);
    }
    
    if (status) {
      where.status = status as string;
    }
    
    if (search) {
      where.OR = [
        { title: { contains: search as string, mode: 'insensitive' } },
        { description: { contains: search as string, mode: 'insensitive' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);
    
    const [strategies, total] = await Promise.all([
      prisma.strategy.findMany({
        where,
        skip,
        take: Number(limit),
        include: {
          createdBy: {
            select: { id: true, name: true },
          },
          _count: {
            select: { plans: true },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.strategy.count({ where }),
    ]);

    res.json({
      success: true,
      data: {
        items: strategies.map(s => ({ ...s, planCount: s._count.plans })),
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error('Get strategies error:', error);
    res.status(500).json({
      success: false,
      error: '获取战略列表失败',
    });
  }
});

// 获取战略详情
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    const strategy = await prisma.strategy.findUnique({
      where: { id },
      include: {
        createdBy: {
          select: { id: true, name: true },
        },
        plans: {
          include: {
            department: {
              select: { id: true, name: true },
            },
            owner: {
              select: { id: true, name: true },
            },
          },
        },
      },
    });

    if (!strategy) {
      return res.status(404).json({
        success: false,
        error: '战略不存在',
      });
    }

    res.json({
      success: true,
      data: strategy,
    });
  } catch (error) {
    console.error('Get strategy error:', error);
    res.status(500).json({
      success: false,
      error: '获取战略信息失败',
    });
  }
});

// 创建战略
router.post('/', async (req: Request, res: Response) => {
  try {
    const { title, description, year, startDate, endDate } = req.body;
    
    const strategy = await prisma.strategy.create({
      data: {
        title,
        description,
        year: Number(year),
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        createdById: req.user!.id,
        status: 'draft',
        progress: 0,
      },
    });

    res.json({
      success: true,
      data: strategy,
    });
  } catch (error) {
    console.error('Create strategy error:', error);
    res.status(500).json({
      success: false,
      error: '创建战略失败',
    });
  }
});

// 更新战略
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { title, description, year, startDate, endDate, status, progress } = req.body;
    
    const updateData: any = {};
    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (year !== undefined) updateData.year = year;
    if (startDate !== undefined) updateData.startDate = new Date(startDate);
    if (endDate !== undefined) updateData.endDate = new Date(endDate);
    if (status !== undefined) updateData.status = status;
    if (progress !== undefined) updateData.progress = progress;
    
    const strategy = await prisma.strategy.update({
      where: { id },
      data: updateData,
    });

    res.json({
      success: true,
      data: strategy,
    });
  } catch (error) {
    console.error('Update strategy error:', error);
    res.status(500).json({
      success: false,
      error: '更新战略失败',
    });
  }
});

// 删除战略
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // 检查是否有关联计划
    const plans = await prisma.plan.count({
      where: { strategyId: id },
    });

    if (plans > 0) {
      return res.status(400).json({
        success: false,
        error: '该战略下存在关联计划，无法删除',
      });
    }

    await prisma.strategy.delete({
      where: { id },
    });

    res.json({
      success: true,
      message: '战略已删除',
    });
  } catch (error) {
    console.error('Delete strategy error:', error);
    res.status(500).json({
      success: false,
      error: '删除战略失败',
    });
  }
});

export default router;
