-- DropForeignKey
ALTER TABLE "DailyLog" DROP CONSTRAINT "DailyLog_weeklyPlanId_fkey";

-- AlterTable
ALTER TABLE "DailyLog" ALTER COLUMN "weeklyPlanId" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "DailyLog" ADD CONSTRAINT "DailyLog_weeklyPlanId_fkey" FOREIGN KEY ("weeklyPlanId") REFERENCES "WeeklyPlan"("id") ON DELETE SET NULL ON UPDATE CASCADE;
